
import hu.allatook.controller.AllatkertKontroller;
import hu.allatook.model.Allatok;
import utils.Utils;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class AllatAddDialog extends Stage {
    public AllatkertKontroller allatokKontr;

    public AllatAddDialog(AllatkertKontroller allatokKontr) {
        this.allatokKontr = allatokKontr;
        construct();
    }

    private void construct() {
        GridPane gridPane = new GridPane();
        gridPane.setVgap(10);
        gridPane.setHgap(10);
        gridPane.setPadding(new Insets(10));

        TextField nevTF = new TextField();
        TextField fajTF = new TextField();
        TextField bemutatkozasTF = new TextField();
        TextField szuletesi_evTF = new TextField();

        gridPane.add(new Text("nev:"), 0, 0);
        gridPane.add(nevTF, 1, 0);
        gridPane.add(new Text("faj:"), 0, 1);
        gridPane.add(fajTF, 1, 1);
        gridPane.add(new Text("bemutatkozas:"), 0, 2);
        gridPane.add(bemutatkozasTF, 1, 2);
        gridPane.add(new Text("Szuletesi ev:"), 0, 3);
        gridPane.add(szuletesi_evTF, 1, 3);

        Button okButton = new Button("OK");
        okButton.setDefaultButton(true);
        okButton.setOnAction(e -> {
            if (nevTF.getText().contentEquals("")) {
                Utils.showWarning("A nev nem lehet ures");
                return;
            }
            if (fajTF.getText().contentEquals("")) {
                Utils.showWarning("A fajt meg kell hatarozni");
                return;
            }
            if (bemutatkozasTF.getText().contentEquals("")) {
                Utils.showWarning("Mondj par mondatot rola");
                return;
            }
            if (szuletesi_evTF.getText().contentEquals("")) {
                Utils.showWarning("Na es mikor szuletett?");
                return;
            }
            int ev;

            try {
                ev = Integer.parseInt(szuletesi_evTF.getText());
            } catch (NumberFormatException nfe) {
                Utils.showWarning("Szamokat irj be kerlek");
                return;
            }

            if (allatokKontr.AddAllat(new Allatok(nevTF.getText(), fajTF.getText(),bemutatkozasTF.getText(), ev))) {
                close();
            } else {
                Utils.showWarning("Nem sikerult a mentes");
                return;
            }
        });

        Button cancelButton = new Button("Cancel");
        cancelButton.setCancelButton(true);
        cancelButton.setOnAction(e -> {
            close();
        });

        FlowPane buttonPane = new FlowPane();
        buttonPane.setOrientation(Orientation.HORIZONTAL);
        buttonPane.setHgap(15);
        buttonPane.setAlignment(Pos.CENTER);
        buttonPane.getChildren().addAll(okButton, cancelButton);

        gridPane.add(buttonPane, 0, 5, 2, 1);

        Scene scene = new Scene(gridPane);
        setScene(scene);
        setTitle("Allat felvetele");
        show();
    }
}
