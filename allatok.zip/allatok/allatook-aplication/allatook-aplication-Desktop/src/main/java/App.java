import hu.allatook.model.Allatok;
import hu.allatook.model.Orokbefogado;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import hu.allatook.controller.AllatkertKontroller;

import java.lang.reflect.Member;
import java.sql.SQLException;

/**
 * JavaFX App
 */

public class App extends Application {

    AllatkertKontroller allatokKontr = new AllatkertKontroller();

    private final MenuBar menuBar = new MenuBar();
    public TableView<Allatok> allatokTable = new TableView<>();
    public TableView<Orokbefogado> orokbefogadoTable = new TableView<>();
    public String actu = "";
    public VBox vboxroot;

    @Override
    public void start(Stage stage) {

        Menu allatkertMenu = new Menu("Allatkert kezelese");
        menuBar.getMenus().add(allatkertMenu);

        Menu orokbefogadokMenu = new Menu("Orokbefogadok kezelse");
        menuBar.getMenus().add(orokbefogadokMenu);

        MenuItem AllatMenuItem = new MenuItem("Allatok listazasa");
        MenuItem addAllatMenuItem = new MenuItem("Allat hozzaadasa");
        MenuItem allatTorlesMenuItem = new MenuItem("Allat torlese");

        MenuItem OrokbefogadokMenuItem = new MenuItem("Orokbefogadok listazasa");
        MenuItem addOrokbefogadoMenuItem = new MenuItem("Orokbefogado hozzaadasa");
        MenuItem OrokbefogadokTorleseMenuItem = new MenuItem("Orokbefogado torlese");

        addAllatMenuItem.setOnAction(e -> new AllatAddDialog(allatokKontr));
        AllatMenuItem.setOnAction(e -> new AllatAddDialog(allatokKontr));
        allatTorlesMenuItem.setOnAction(e -> new AllatDeleteDialog(allatokKontr));


        addOrokbefogadoMenuItem.setOnAction(e -> new OrokbefogadoAddDialog(allatokKontr));
        addOrokbefogadoMenuItem.setOnAction(e-> new OrokbefogadoAddDialog(allatokKontr));
        addOrokbefogadoMenuItem.setOnAction(e -> new OrokbefogadoAddDialog(allatokKontr));


        allatkertMenu.getItems().addAll(addAllatMenuItem);
        allatkertMenu.getItems().addAll(allatTorlesMenuItem);
        allatkertMenu.getItems().addAll(AllatMenuItem);

        orokbefogadokMenu.getItems().addAll(addOrokbefogadoMenuItem);
        orokbefogadokMenu.getItems().addAll(OrokbefogadokTorleseMenuItem);
        orokbefogadokMenu.getItems().addAll(OrokbefogadokMenuItem);

        AllatMenuItem.setOnAction(e->{
            constructAllatTable();
        });

        OrokbefogadokMenuItem.setOnAction(e->{
            try {
                constructOrokbefogadokTable();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });

        AllatMenuItem.setOnAction(e ->{
            constructAllatTable();
            actu = "allatok";
        });

        OrokbefogadokMenuItem.setOnAction(e ->{
            try {
                constructOrokbefogadokTable();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            actu = "orokbefogadok";
        });

        Button refresh = new Button("Frissit");
        refresh.setOnAction(e -> {
            if(actu.equals("allatok")) {
                allatokTable.setItems(FXCollections.observableArrayList(allatokKontr.listAllatok()));
            } else if(actu.equals(("orokbefogadok"))){
                orokbefogadoTable.setItems(FXCollections.observableArrayList(allatokKontr.listOrokbefogadok()));
            }
        });

        vboxroot = new VBox(menuBar, orokbefogadoTable, refresh);
        vboxroot.setSpacing(10);
        Scene scene = new Scene(vboxroot, 400, 400);

        stage.setScene(scene);
        stage.show();
    }

    private void constructAllatTable() {
        allatokTable.setEditable(false);

        TableColumn<Allatok, String> IDCol = new TableColumn<>("ID");
        IDCol.setCellValueFactory(new PropertyValueFactory<Allatok, String>("ID"));

        TableColumn<Allatok, String> nameCol = new TableColumn<>("nev");
        nameCol.setCellValueFactory(new PropertyValueFactory<Allatok, String>("nev"));

        TableColumn<Allatok, String> fajCol = new TableColumn<>("faj");
        fajCol.setCellValueFactory(new PropertyValueFactory<Allatok, String>("faj"));

        TableColumn<Allatok, String> bemutatkozasCol = new TableColumn<>("bemutatkozas");
        bemutatkozasCol.setCellValueFactory(new PropertyValueFactory<Allatok, String>("bemutatkozas"));

        TableColumn<Allatok, Integer> szuletettCol = new TableColumn<>("szuletesi_ev");
        szuletettCol.setCellValueFactory(new PropertyValueFactory<Allatok, Integer>("szuletesi_ev"));

       // allatokTable.getColumns().addAll(IDCol,nameCol, fajCol, bemutatkozasCol,szuletettCol);
        //allatokTable.setItems(FXCollections.observableArrayList(allatokKontr.listAllatok()));

        allatokTable.getColumns().addAll(IDCol, nameCol, fajCol, bemutatkozasCol, szuletettCol);
        allatokTable.setItems(FXCollections.observableArrayList(allatokKontr.listAllatok()));
        vboxroot.getChildren().set(1,allatokTable);
    }

    private void constructOrokbefogadokTable() throws SQLException {
        orokbefogadoTable.setEditable(false);
        orokbefogadoTable = new TableView<>();

        TableColumn<Orokbefogado, Integer> IDCOL = new TableColumn<>("ID");
        IDCOL.setCellValueFactory(new PropertyValueFactory<Orokbefogado, Integer>("ID"));

        TableColumn<Orokbefogado, String> nameCol = new TableColumn<>("nev");
        nameCol.setCellValueFactory(new PropertyValueFactory<Orokbefogado, String>("nev"));

        TableColumn<Orokbefogado, String> telefonCol = new TableColumn<>("telefon_szam");
        telefonCol.setCellValueFactory(new PropertyValueFactory<Orokbefogado, String>("telefon_szam"));

        TableColumn<Orokbefogado, String> emailCol = new TableColumn<>("email");
        emailCol.setCellValueFactory(new PropertyValueFactory<Orokbefogado, String>("email"));

        TableColumn<Orokbefogado, Integer> csatlakozasCol = new TableColumn<>("csatlakozas_idopontja");
        csatlakozasCol.setCellValueFactory(new PropertyValueFactory<Orokbefogado, Integer>("csatlakozas_idopontja"));

        orokbefogadoTable.getColumns().addAll(IDCOL, nameCol, telefonCol, emailCol, csatlakozasCol);
        orokbefogadoTable.setItems(FXCollections.observableArrayList(allatokKontr.listOrokbefogadok()));
        vboxroot.getChildren().set(1,orokbefogadoTable);
    }

    public static void main(String[] args) {
        launch();
    }

}