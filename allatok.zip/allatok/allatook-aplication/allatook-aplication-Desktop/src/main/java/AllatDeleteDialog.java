import hu.allatook.controller.AllatkertKontroller;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import utils.Utils;

import java.sql.SQLException;

public class AllatDeleteDialog extends Stage {

    AllatkertKontroller kontrol;

    public AllatDeleteDialog(AllatkertKontroller kontroller) {
        this.kontrol = kontroller;
        construct();
    }

    private void construct() {
            GridPane gridPane = new GridPane();
            gridPane.setVgap(10);
            gridPane.setHgap(10);
            gridPane.setPadding(new Insets(10));

            TextField idTF = new TextField();

            gridPane.add(new Text("ID:"), 0, 0);
            gridPane.add(idTF, 1, 0);

            Button okButton = new Button("OK");
            okButton.setDefaultButton(true);
            okButton.setOnAction(e -> {
                if (idTF.getText().contentEquals("")) {
                    Utils.showWarning("Meg kell adnod egy ID-t");
                    return;
                }

                int id = Integer.parseInt(idTF.getText());

                if (kontrol.AllatokTorlese(id)) {
                    close();
                } else {
                    Utils.showWarning("The save didn't succeed");
                    return;
                }
            });

            Button cancelButton = new Button("Cancel");
            cancelButton.setCancelButton(true);
            cancelButton.setOnAction(e -> {
                close();
            });

            FlowPane buttonPane = new FlowPane();
            buttonPane.setOrientation(Orientation.HORIZONTAL);
            buttonPane.setHgap(15);
            buttonPane.setAlignment(Pos.CENTER);
            buttonPane.getChildren().addAll(okButton, cancelButton);

            gridPane.add(buttonPane, 0, 5, 2, 1);

            Scene scene = new Scene(gridPane);
            setScene(scene);
            setTitle("Delete animal");
            show();
    }
}

