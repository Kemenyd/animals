package hu.allatook.model;

public class Orokbefogado {
    private int ID;
    private String nev;
    private String telefon_szam;
    private String email;
    private int csatlakozas_idopontja;

    public Orokbefogado() {
    }

    public Orokbefogado(String nev, String telefon_szam, String email, int csatlakozas_idopontja) {
        this.nev = nev;
        this.telefon_szam = telefon_szam;
        this.email = email;
        this.csatlakozas_idopontja = csatlakozas_idopontja;
    }

    public Orokbefogado(int ID, String nev, String telefon_szam, String email, int csatlakozas_idopontja) {
        this.ID = ID;
        this.nev = nev;
        this.telefon_szam = telefon_szam;
        this.email = email;
        this.csatlakozas_idopontja = csatlakozas_idopontja;
    }

    @Override
    public String toString() {
        return "Orokbefogado{" +
                "ID=" + ID +
                ", nev='" + nev + '\'' +
                ", telefon_szam=" + telefon_szam +
                ", email='" + email + '\'' +
                ", csatlakozas_idopontja=" + csatlakozas_idopontja +
                '}';
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public String getTelefon_szam() {
        return telefon_szam;
    }

    public void setTelefon_szam(String telefon_szam) {
        this.telefon_szam = telefon_szam;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getCsatlakozas_idopontja() {
        return csatlakozas_idopontja;
    }

    public void setCsatlakozas_idopontja(int csatlakozas_idopontja) {
        this.csatlakozas_idopontja = csatlakozas_idopontja;
    }
}
