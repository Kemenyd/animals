package hu.allatook.model;

public class orokbefogad {
    private int ID;
    private int idopont;
    private String tamogatas_tipusa;
    private String tamogatas_mennyisege;
    private String tamogatas_gyakorisaga;

    public orokbefogad() {
    }

    public orokbefogad(int ID, int idopont, String tamogatas_tipusa, String tamogatas_mennyisege, String tamogatas_gyakorisaga) {
        this.ID = ID;
        this.idopont = idopont;
        this.tamogatas_tipusa = tamogatas_tipusa;
        this.tamogatas_mennyisege = tamogatas_mennyisege;
        this.tamogatas_gyakorisaga = tamogatas_gyakorisaga;
    }

    @Override
    public String toString() {
        return "orokbefogad{" +
                "ID=" + ID +
                ", idopont=" + idopont +
                ", tamogatas_tipusa='" + tamogatas_tipusa + '\'' +
                ", tamogatas_mennyisege='" + tamogatas_mennyisege + '\'' +
                ", tamogatas_gyakorisaga='" + tamogatas_gyakorisaga + '\'' +
                '}';
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getIdopont() {
        return idopont;
    }

    public void setIdopont(int idopont) {
        this.idopont = idopont;
    }

    public String getTamogatas_tipusa() {
        return tamogatas_tipusa;
    }

    public void setTamogatas_tipusa(String tamogatas_tipusa) {
        this.tamogatas_tipusa = tamogatas_tipusa;
    }

    public String getTamogatas_mennyisege() {
        return tamogatas_mennyisege;
    }

    public void setTamogatas_mennyisege(String tamogatas_mennyisege) {
        this.tamogatas_mennyisege = tamogatas_mennyisege;
    }

    public String getTamogatas_gyakorisaga() {
        return tamogatas_gyakorisaga;
    }

    public void setTamogatas_gyakorisaga(String tamogatas_gyakorisaga) {
        this.tamogatas_gyakorisaga = tamogatas_gyakorisaga;
    }
}
