package hu.allatook.controller;

import hu.allatook.DAO.allatokDAO;
import hu.allatook.DAO.allatokDAOImpl;
import hu.allatook.model.Allatok;
import hu.allatook.model.Orokbefogado;
import hu.allatook.model.orokbefogad;

import java.util.List;

public class AllatkertKontroller {
    private allatokDAO allatokDAO = new allatokDAOImpl();
    private static AllatkertKontroller single_instance = null;

    public AllatkertKontroller(){
    }

    public static AllatkertKontroller getInstance(){
        if(single_instance == null){
            single_instance = new AllatkertKontroller();
        }
        return single_instance;
    }

    public List<Allatok> listAllatok(){
        return allatokDAO.listAllatok();
    }
    public List<Orokbefogado> listOrokbefogadok(){
        return allatokDAO.listOrokbefogadok();
    }
    public List<orokbefogad> listOrokbefogad(){
        return allatokDAO.listOrokbefogad();
    }

    public boolean AddAllat(Allatok allat){
        return allatokDAO.addAllatok(allat);
    }
    public boolean AddOrokbefogado(Orokbefogado tulaj){
        return allatokDAO.addOrokbefogadok(tulaj);
    }
    public boolean AddOrokbefogadas(orokbefogad orokbefogad){
        return allatokDAO.addOrokbefogadas(orokbefogad);
    }

    public boolean AllatokTorlese(int id) {
        return allatokDAO.AllatokTorlese(id);
    }

    public boolean OrokbefogadokTorlese(int id) {
        return allatokDAO.OrokbefogadokTorlese(id);
    }
}
