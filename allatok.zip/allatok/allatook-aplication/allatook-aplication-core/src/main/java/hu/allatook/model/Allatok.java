package hu.allatook.model;

public class Allatok {
    private int ID;
    private String nev;
    private String faj;
    private String bemutatkozas;
    private int szuletesi_ev;

    public Allatok(int ID, String nev, String faj, String bemutatkozas, int szuletesi_ev) {
        this.ID = ID;
        this.nev = nev;
        this.faj = faj;
        this.bemutatkozas = bemutatkozas;
        this.szuletesi_ev = szuletesi_ev;
    }

    public Allatok(String nev, String faj, String bemutatkozas, int szuletesi_ev) {
        this.nev = nev;
        this.faj = faj;
        this.bemutatkozas = bemutatkozas;
        this.szuletesi_ev = szuletesi_ev;
    }

    public Allatok() {
    }

    @Override
    public String toString() {
        return "Allatok{" +
                "ID=" + ID +
                ", nev='" + nev + '\'' +
                ", faj='" + faj + '\'' +
                ", bemutatkozas='" + bemutatkozas + '\'' +
                ", birthYear=" + szuletesi_ev +
                '}';
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public String getFaj() {
        return faj;
    }

    public void setFaj(String faj) {
        this.faj = faj;
    }

    public String getBemutatkozas() {
        return bemutatkozas;
    }

    public void setBemutatkozas(String bemutatkozas) {
        this.bemutatkozas = bemutatkozas;
    }

    public int getSzuletesi_ev() {
        return szuletesi_ev;
    }

    public void setSzuletesi_ev(int szuletesi_ev) {
        this.szuletesi_ev = szuletesi_ev;
    }
}
