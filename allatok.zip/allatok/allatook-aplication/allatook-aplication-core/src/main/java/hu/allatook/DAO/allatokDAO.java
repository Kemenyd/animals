package hu.allatook.DAO;

import hu.allatook.model.Allatok;
import hu.allatook.model.Orokbefogado;
import hu.allatook.model.orokbefogad;

import java.util.List;

public interface allatokDAO {
    List<Allatok> listAllatok();
    boolean addAllatok(Allatok a);
    boolean AllatokTorlese(int id);


    List<Orokbefogado> listOrokbefogadok();
    boolean addOrokbefogadok(Orokbefogado o);
    boolean OrokbefogadokTorlese(int id);

    List<orokbefogad> listOrokbefogad();
    boolean addOrokbefogadas(orokbefogad adopt);
}
