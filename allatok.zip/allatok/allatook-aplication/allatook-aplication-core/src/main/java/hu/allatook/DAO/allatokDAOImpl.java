package hu.allatook.DAO;

import hu.allatook.model.Allatok;
import hu.allatook.model.Orokbefogado;
import hu.allatook.model.orokbefogad;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class allatokDAOImpl implements allatokDAO {
    private static final String CONN_STR = "jdbc:sqlite:D:/InteliJ/tomcat/apache-tomcat-9.0.34/bin/allatkert.db";
    private static final String SELECT_ALL_ALLAT = "SELECT * FROM Allatok;";
    private static final String SELECT_ALL_OROKBEFOGADO = "SELECT * FROM Orokbefogadok;";
    private static final String SELECT_ALL_OROKBEFOGADAS = "SELECT * FROM orokbefogadas;";
    private static final String INSERT_ALLAT = "INSERT INTO Allatok ('nev','faj','bemutatkozas','szuletesi_ev') VALUES" + "(?,?,?,?);";
    private static final String INSERT_OROKBEFOGADO = "INSERT INTO Orokbefogadok ('nev','telefon_szam','email','csatlakozas_idopontja') VALUES" + "(?,?,?,?);";
    private static final String INSERT_OROKBEFOGADAS = "INSERT INTO orokbefogadas ('idopont','tamogatas_tipusa','tamogatas_mennyisege','tamogatas_gyakorisaga') VALUES" + "(?,?,?,?);";
    private static final String DELETE_ANIMAL = "DELETE FROM Allatok WHERE id=?";
    private static final String DELETE_OROKBEFOGADO = "DELETE FROM Allatok WHERE id=?";


    public allatokDAOImpl() {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Allatok> listAllatok() {
        List<Allatok> result = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(CONN_STR);
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(SELECT_ALL_ALLAT)
        ) {
            while (rs.next()) {
                Allatok a = new Allatok(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getInt(5)
                );
                result.add(a);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return result;
    }

    @Override
    public boolean addAllatok(Allatok a) {

        try (Connection conn = DriverManager.getConnection(CONN_STR);
             PreparedStatement st = conn.prepareStatement(INSERT_ALLAT)
        ) {
            st.setString(1, a.getNev());
            st.setString(2, a.getFaj());
            st.setString(3, a.getBemutatkozas());
            st.setInt(4, a.getSzuletesi_ev());
            int res = st.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean AllatokTorlese(int id) {
        boolean d = false;

        try(Connection conn = DriverManager.getConnection(CONN_STR);){
            PreparedStatement pst = conn.prepareStatement(DELETE_ANIMAL);
            pst.setInt(1, id);
            int row = pst.executeUpdate();
            if (row == 1) {
                d = true;
            }
            return d;
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Orokbefogado> listOrokbefogadok() {
        List<Orokbefogado> orokbefogadok = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(CONN_STR);
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(SELECT_ALL_OROKBEFOGADO)
        ) {
            while (rs.next()) {
                Orokbefogado orokbefogado = new Orokbefogado(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getInt(5)
                );
                orokbefogadok.add(orokbefogado);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }


        return orokbefogadok;
    }

    @Override
    public boolean addOrokbefogadok(Orokbefogado o) {

        try (Connection conn = DriverManager.getConnection(CONN_STR);
             PreparedStatement st = conn.prepareStatement(INSERT_OROKBEFOGADO)
        ) {
            st.setString(1, o.getNev());
            st.setString(2, o.getTelefon_szam());
            st.setString(3, o.getEmail());
            st.setInt(4, o.getCsatlakozas_idopontja());
            int res = st.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public List<orokbefogad> listOrokbefogad() {
        List<orokbefogad> orokbe = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(CONN_STR);
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(SELECT_ALL_OROKBEFOGADAS)
        ) {
            while (rs.next()) {
                orokbefogad orokbefogadas = new orokbefogad(
                        rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5)
                );
                orokbe.add(orokbefogadas);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return orokbe;
    }

    @Override
    public boolean addOrokbefogadas(orokbefogad adopt) {

        try (Connection conn = DriverManager.getConnection(CONN_STR);
             PreparedStatement st = conn.prepareStatement(INSERT_OROKBEFOGADAS)
        ) {
            st.setInt(1, adopt.getIdopont());
            st.setString(2, adopt.getTamogatas_tipusa());
            st.setString(3, adopt.getTamogatas_mennyisege());
            st.setString(4, adopt.getTamogatas_gyakorisaga());
            int res = st.executeUpdate();
            if (res == 1) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean OrokbefogadokTorlese(int id) {
        boolean d = false;

        try(Connection conn = DriverManager.getConnection(CONN_STR);){
            PreparedStatement pst = conn.prepareStatement(DELETE_OROKBEFOGADO);
            pst.setInt(1, id);
            int row = pst.executeUpdate();
            if (row == 1) {
                d = true;
            }
            return d;
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
