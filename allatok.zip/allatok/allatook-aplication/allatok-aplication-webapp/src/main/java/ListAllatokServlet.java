import hu.allatook.DAO.allatokDAO;
import hu.allatook.DAO.allatokDAOImpl;
import hu.allatook.model.Allatok;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/orokbefogadok")
public class ListAllatokServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        resp.setContentType("text/html");
       allatokDAO allatok = new allatokDAOImpl();
        PrintWriter pw = resp.getWriter();
        try {
            pw.print("<head>");
            pw.print("<title>Állatkert</title>");
            pw.print("</head>");
            pw.print("<header>");
            pw.print("<h2 style='text-align: center; font-size: 35px; color: white; background-color: #500; padding: 20px;'>Az állatkert örökbefogadott állatai</h2>");
            pw.print("</header>");
            pw.print("<table style:'width:100%;'>");
            pw.println("<tr><th style='text-algin:center; font-size:22; width: 20%; padding-left: 5px'><sub>ID</sub></th>");
            pw.println("<th style='text-algin: center; font-size:22;width: 20%; padding-left: 5px'><sub>Neve</sub></th>");
            pw.println("<th style='text-algin: center; font-size:22;width: 20%; padding-left: 5px'><sub>Faja</sub></th>");
            pw.println("<th style='text-algin: center; font-size:22;width: 20%; padding-left: 5px'><sub>Bemutatkozasa</sub></th>");
            pw.println("<th style='text-algin: center; font-size:22;width: 20%; padding-left: 5px'><sub>Szuletesi eve</sub></th></tr>");
            pw.print("<hr></hr>");

            for (Allatok a : allatok.listAllatok()) {
                pw.println("<tr style='border: 3px solid black;'><td style='text-align: center; width: 20%; padding-left: 5px'>" + a.getID() + "</td>");
                pw.println("<td style='text-align: center; width: 20%; padding-left: 5px'>" + a.getNev() + "</td>");
                pw.println("<td style='text-align: center; width: 20%; padding-left: 5px'>" + a.getFaj() + "</td>");
                pw.println("<td style='text-align: center; width: 20%; padding-left: 5px'>" + a.getBemutatkozas() + "</td>");
                pw.println("<td style='text-align: center; width: 20%; padding-left: 5px'>" + a.getSzuletesi_ev() + "</td></tr>");
            }
            pw.print("</table>");
        } finally {

        }
    }
}
