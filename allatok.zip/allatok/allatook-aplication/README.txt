Az állatalam válaszott projectet az Állatkert.
Az egész project JAVA 11 és Tomcat 9.0.034 el működik biztosan, ugyanis ezen eszközök segítségével lett létrehozva. 
A projectemben a web alkalmazás a kilistázásért felel, ahol a user meg tudja nézni
az adatbázisban szereplő állatokat. Az állatok mellett örökbefogadó személyek
 adatainak kilistázására is lehetőség van.
Az adatbázis neve: allatkert.db ez a fő mappa mellett található a zipben. 
Amikor én futtattam és tesztelgettem például következő út megadásával mindig elértem 
az adatbázist. 

	*PÉLDA*:
private static final String CONN_STR = "jdbc:sqlite:D:/InteliJ/Projects/beadando/allatkert.db";

Ekkor a tomcat szerverhez allatook-aplication-webapp:war artifact volt hozzáadva.


Az asztali verzióban található: 
		- az Állat táblára vonatkozó törlés, új rekord felvétele és maga a listázás.
		- az Örökbefogadók táblára vonatkozó törlés, új rekord felvétele és maga a listázás.

A desktop részt ugye a Mavennel szükséges fordítani. Maven fülben allatook-aplication-Desktop pluginsok fül alatt 
	clean: clean, compiler:compile, javafx:run


Előre is köszönöm az értékelésed és remélem jól sikerült minden! :)
Sok sikert a vizsgákhoz!